package com.example.gerar.connect4;

        import android.content.Context;
        import android.graphics.Color;
        import android.graphics.drawable.Drawable;
        import android.view.Gravity;
        import android.widget.Button;
        import android.widget.GridLayout;
        import android.widget.ImageView;
        import android.widget.TextView;

public class ButtonGridAndTextView extends GridLayout {
    public static final int SIDEX = 7;
    public static final int SIDEY = 6;
    private ImageView [][] circleImage;
    private Button [] buttons;
    private TextView status;

    public ButtonGridAndTextView( Context context, int width, int height,
                                  OnClickListener listener ) {
        super( context );
        // Set # of rows and columns of this GridLayout
        setColumnCount( SIDEX );
        setRowCount( SIDEY + 2 );




        Drawable circle = getContext().getResources().getDrawable(R.drawable.circle);
        circleImage = new ImageView[SIDEX][SIDEY];
        for( int row = 0; row < SIDEY; row++ ){
            for( int col = 0; col < SIDEX; col++ ) {
                circleImage[col][row] = new ImageView( context );
                circleImage[col][row].setBackground(circle);
                addView( circleImage[col][row], width, height );
            }
        }

        // Create the buttons and add them to this GridLayout
        buttons = new Button[SIDEX];
        for( int col = 0; col < SIDEX; col++ ) {
            buttons[col] = new Button( context );
            buttons[col].setOnClickListener( listener );
            addView( buttons[col], width, height);
        }


        // set up layout parameters of 4th row of gridLayout
        status = new TextView( context );

        Spec rowSpec = GridLayout.spec( SIDEY+1, 1);
        Spec columnSpec = GridLayout.spec( 0, SIDEX );
        LayoutParams lpStatus
                = new LayoutParams( rowSpec, columnSpec);
        status.setLayoutParams( lpStatus );

        // set up status' characteristics
        status.setWidth( width*SIDEX);
        status.setHeight( height );
        status.setGravity( Gravity.CENTER );
        status.setTextSize((int)(width*.15));
        addView( status );
    }

    public void setStatusText( String text ) {
        status.setText( text );
    }

    public void setStatusBackgroundColor( int color ) {
        status.setBackgroundColor( color );
    }

    public void setCircleBackground( int column, int row, int color ) {
        circleImage[column][SIDEY-row-1].setBackgroundColor(color);
    }

    public boolean isButton( Button b, int column ) {
        return ( b == buttons[column] );
    }

    public void resetButtons( ) {
        Drawable circle = getContext().getResources().getDrawable(R.drawable.circle);
        for( int row = 0; row < SIDEY; row++ )
            for( int col = 0; col < SIDEX; col++ )
                circleImage[col][row].setBackground(circle);
        setStatusText("Player 1's Turn");
        setStatusBackgroundColor(Color.RED);
    }

    public void enableButtons( boolean enabled ) {
            for( int col = 0; col < SIDEX; col++ )
                buttons[col].setEnabled( enabled );
    }
}
