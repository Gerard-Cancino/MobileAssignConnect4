package com.example.gerar.connect4;

        import android.content.DialogInterface;
        import android.graphics.Color;
        import android.graphics.Point;
        import android.os.Bundle;
        import android.support.v7.app.AlertDialog;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Connect4 game;
    private ButtonGridAndTextView tttView;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        game = new Connect4( );
        Point size = new Point( );
        getWindowManager().getDefaultDisplay( ).getSize( size );
        int width = size.x / Connect4.SIDEX;
        int height = size.y / (Connect4.SIDEY+3);
        ButtonHandler bh = new ButtonHandler( );
        tttView = new ButtonGridAndTextView( this, width, height, bh );
        tttView.resetButtons();
        setContentView( tttView );
    }

    public void showNewGameDialog( ) {
        AlertDialog.Builder alert = new AlertDialog.Builder( this );
        alert.setTitle( "This is fun" );
        alert.setMessage( "Play again?" );
        PlayDialog playAgain = new PlayDialog( );
        alert.setPositiveButton( "YES", playAgain );
        alert.setNegativeButton( "NO", playAgain );
        alert.show( );
    }

    private class ButtonHandler implements View.OnClickListener {
        public void onClick( View v ) {
                for( int col = 0; col < game.SIDEX; col++ ) {
                    if( tttView.isButton( (Button) v, col ) ) {
                        if(game.getRowOfCol(col)<5) {
                            int play = game.play(col);
                            int row = game.getRowOfCol(col);
                            if (play == 1) {
                                tttView.setCircleBackground(col, row, Color.RED);
                                tttView.setStatusBackgroundColor(Color.BLUE);
                                tttView.setStatusText("Player 2's Turn");
                            }
                            else if (play == 2) {
                                tttView.setCircleBackground(col, row, Color.BLUE);
                                tttView.setStatusBackgroundColor(Color.RED);
                                tttView.setStatusText("Player 1's Turn");
                            }
                            //else play == 0

                            int check = game.isGameOver(col, row);
                            if (check >= 0) {
                                tttView.enableButtons(false);
                                tttView.setStatusText(game.result(check));
                                tttView.setStatusBackgroundColor( Color.GREEN );
                                showNewGameDialog();    // offer to play again;
                            }
                        }
                        else
                            tttView.setStatusText("Please choose a valid column");

                    }
                }

        }
    }

    private class PlayDialog implements DialogInterface.OnClickListener {
        public void onClick( DialogInterface dialog, int id ) {
            if( id == -1 ) /* YES button */ {
                game.resetGame( );
                tttView.enableButtons( true );
                tttView.resetButtons( );

            }
            else if( id == -2 ) // NO button
                MainActivity.this.finish( );
        }
    }
}