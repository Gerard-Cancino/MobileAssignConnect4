package com.example.gerar.connect4;

/**
 * Created by gerar on 2/26/2018.
 */

public class Connect4 {
    public static final int SIDEX = 7;
    public static final int SIDEY = 6;
    private int turn;
    private int [][] game;
    private int [] indexOfImage;

    public Connect4( ) {
        game = new int[SIDEX][SIDEY];
        indexOfImage = new int[SIDEX];
        resetGame( );
    }

    public int play(int col ) {
        int currentTurn = turn;
        if( indexOfImage[col] >= -1 && col >= 0 && col < SIDEX && indexOfImage[col] < SIDEY) {
            ++indexOfImage[col];
            game[col][indexOfImage[col]] = turn;
            if( turn == 1 )
                turn = 2;
            else
                turn = 1;
            return currentTurn;
        }
        else
            return 0;
    }

    public int getRowOfCol(int col){
        return indexOfImage[col];
    }

    public int whoWon(int col, int row) {
        boolean checkRow = checkRows(col,row);
        boolean checkCol = checkColumns(col,row);
        boolean checkPosDiag = checkPosDiagonals(col,row);
        boolean checkNegDiag = checkNegDiagonals(col,row);
        if(checkRow||checkCol || checkNegDiag || checkPosDiag)
            return game[col][row];
        return 0;
    }

    protected boolean checkRows(int col, int row) {
        int returnGameOver = 1;
        if(col<SIDEX-1){
            int checkCol = col+1;
            while(game[checkCol][row]==game[col][row]){
                ++returnGameOver;
                if(checkCol<SIDEX-1)
                    ++checkCol;
                else
                    break;
            }
        }
        if(col>0){
            int checkCol = col-1;
            while(game[checkCol][row]==game[col][row]){
                ++returnGameOver;
                if(checkCol>0)
                    --checkCol;
                else
                    break;
            }
        }
        if (returnGameOver>=4)
            return true;
        else
            return false;
    }

    protected boolean checkColumns(int col, int row) {
        int returnGameOver = 1;
        if(row>2){
            int checkRow = row-1;
            while(game[col][checkRow]==game[col][row]){
                ++returnGameOver;
                if(checkRow>0)
                    --checkRow;
                else
                    break;
            }
        }
        if (returnGameOver>=4)
            return true;
        else
            return false;
    }

    protected boolean checkPosDiagonals(int col, int row) {
        int returnGameOver = 1;
        if(row<SIDEY-1&&col<SIDEX-1){
            int checkCol = col+1;
            int checkRow = row+1;
            while(game[checkCol][checkRow]==game[col][row]){
                ++returnGameOver;
                if(checkRow<SIDEY-1&&checkCol<SIDEX-1) {
                    ++checkCol;
                    ++checkRow;
                }
                else
                    break;
            }
        }
        if(row>0&&col>0){
            int checkCol = col-1;
            int checkRow = row-1;
            while(game[checkCol][checkRow]==game[col][row]){
                ++returnGameOver;
                if(checkRow>0&&checkCol>0) {
                    --checkCol;
                    --checkRow;
                }
                else
                    break;
            }
        }
        if (returnGameOver>=4)
            return true;
        else
            return false;
    }

    protected boolean checkNegDiagonals(int col, int row) {
        int returnGameOver = 1;
        if(row<SIDEY-1&&col>0){
            int checkCol = col-1;
            int checkRow = row+1;
            while(game[checkCol][checkRow]==game[col][row]){
                ++returnGameOver;
                if(checkRow<SIDEY-1&&checkCol>0) {
                    --checkCol;
                    ++checkRow;
                }
                else
                    break;
            }
        }
        if(row>0&&col<SIDEX-1){
            int checkCol = col+1;
            int checkRow = row-1;
            while(game[checkCol][checkRow]==game[col][row]){
                ++returnGameOver;
                if(checkRow>0&&checkCol<SIDEX-1) {
                    ++checkCol;
                    --checkRow;
                }
                else
                    break;
            }
        }
        if (returnGameOver>=4)
            return true;
        else
            return false;
    }



    public boolean canNotPlay( ) {
        boolean result = true;
            for( int col = 0; col < SIDEX; col++ )
                for (int row = 0; row < SIDEY; row++)
                if ( game[col][row] == 0 )
                    result = false;
        return result;
    }

    public int isGameOver(int col, int row) {
        int returnWinner = whoWon(col,row);
        if(returnWinner > 0 )
            return returnWinner;
        else if(canNotPlay())
            return 0;
        else
            return -1;
    }

    public void resetGame( ) {
        for (int row = 0; row < SIDEY; row++)
            for( int col = 0; col < SIDEX; col++ )
                game[col][row] = 0;
        for (int col = 0; col < SIDEX; col++)
            indexOfImage[col]=-1;
        turn = 1;
    }


    public String result(int check) {
        if( check > 0 )
            return "Player " + check + " won";
        else if( canNotPlay( ) )
            return "Tie Game";
        //???Would this even print out?  Cuz this function is only used when player wins or ties
        else
            return "PLAY !!";
    }

}

